## CRUD Bootstrap Table Example

* Install
```
# linux maybe you need sudo
npm install -g json-server
```

* Run
```
json-server -p 3001 db.json
```